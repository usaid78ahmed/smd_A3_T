package com.amnabatool.assignment_1

data class Follower(
    val name: String,
    val profileImageResId: Int
)
