package com.amnabatool.assignment_1

data class Contact(
    val name: String,
    val imageResId: Int
)
